#################################################################
# FILE : additional_file.py
# WRITER : Michael Hasson , mikey641 , 322893892
# EXERCISE : intro2cs2 ex1 2020
# DESCRIPTION: Module that contains one function printing text to pass the submission response.
#################################################################

def secret_function():
    print ("My username is mikey641 and I realize that not checking the submission response can have consequences for"
           " my grade.")

